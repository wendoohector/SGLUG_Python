from slugify import text_to_slug
slug=text_to_slug("Nenpòt text la li ye mèt gen aksan")
print(slug)
